from __future__ import annotations

import os

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from src.api.schemas import (
    ChannelRegisterRequest,
    ChannelRegisterResponse,
    ChannelResponse,
    FeedResponse,
    RunResponse,
    ScheduleEntryResponse,
    AssetResponse,
    GenerateScheduleRequest,
    GenerateScheduleResponse,
)
from src.api.service import (
    get_active_schedule,
    get_channel_runs,
    get_channels,
    get_feeds,
    get_channel_assets,
    get_run_schedule_json,
    get_active_schedule_json,
    register_channel,
)
from src.common.logging_config import get_logger, setup_logging
from src.scheduler.service import generate_schedule

setup_logging()
logger = get_logger("api.main")
app = FastAPI(title="Channel Scheduler API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8080", "http://127.0.0.1:8080"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health() -> dict[str, str]:
    logger.debug("Health check requested")
    return {"status": "ok"}


@app.post("/channels/register", response_model=ChannelRegisterResponse)
def register_channel_route(payload: ChannelRegisterRequest) -> ChannelRegisterResponse:
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        raise HTTPException(status_code=500, detail="DATABASE_URL is not set")
    try:
        logger.info(
            "Register channel request channel_service_id=%s mrss_url=%s",
            payload.channel_service_id,
            payload.mrss_url,
        )
        response = register_channel(db_url=db_url, payload=payload)
        logger.info(
            "Register channel completed channel_service_id=%s feed_id=%s assets_upserted=%s ingestion_error=%s",
            response.channel_service_id,
            response.mrss_feed_id,
            response.assets_upserted,
            response.ingestion_error,
        )
        return response
    except Exception as exc:
        logger.exception("Register channel failed: %s", exc)
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/feeds", response_model=list[FeedResponse])
def feeds_route() -> list[FeedResponse]:
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        raise HTTPException(status_code=500, detail="DATABASE_URL is not set")
    feeds = get_feeds(db_url)
    logger.info("Fetched feeds count=%s", len(feeds))
    return feeds


@app.get("/channels", response_model=list[ChannelResponse])
def channels_route() -> list[ChannelResponse]:
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        raise HTTPException(status_code=500, detail="DATABASE_URL is not set")
    channels = get_channels(db_url)
    logger.info("Fetched channels count=%s", len(channels))
    return channels


@app.get("/channels/{channel_service_id}/runs", response_model=list[RunResponse])
def channel_runs_route(channel_service_id: str) -> list[RunResponse]:
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        raise HTTPException(status_code=500, detail="DATABASE_URL is not set")
    runs = get_channel_runs(db_url, channel_service_id)
    logger.info(
        "Fetched channel runs channel_service_id=%s count=%s",
        channel_service_id,
        len(runs),
    )
    return runs


@app.get(
    "/channels/{channel_service_id}/schedule/active",
    response_model=list[ScheduleEntryResponse],
)
def active_schedule_route(channel_service_id: str) -> list[ScheduleEntryResponse]:
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        raise HTTPException(status_code=500, detail="DATABASE_URL is not set")
    entries = get_active_schedule(db_url, channel_service_id)
    logger.info(
        "Fetched active schedule channel_service_id=%s count=%s",
        channel_service_id,
        len(entries),
    )
    return entries


@app.get("/channels/{channel_service_id}/assets", response_model=list[AssetResponse])
def channel_assets_route(channel_service_id: str) -> list[AssetResponse]:
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        raise HTTPException(status_code=500, detail="DATABASE_URL is not set")
    assets = get_channel_assets(db_url, channel_service_id)
    logger.info(
        "Fetched channel assets channel_service_id=%s count=%s",
        channel_service_id,
        len(assets),
    )
    return assets


@app.post(
    "/channels/{channel_service_id}/schedule/generate",
    response_model=GenerateScheduleResponse,
)
def generate_schedule_route(
    channel_service_id: str, payload: GenerateScheduleRequest
) -> GenerateScheduleResponse:
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        raise HTTPException(status_code=500, detail="DATABASE_URL is not set")
    try:
        logger.info(
            "Generate schedule request channel_service_id=%s window_hours=%s trigger_type=%s schedule_type=%s",
            channel_service_id,
            payload.window_hours,
            payload.trigger_type,
            payload.schedule_type,
        )
        result = generate_schedule(
            db_url=db_url,
            channel_service_id=channel_service_id,
            window_hours=payload.window_hours,
            trigger_type=payload.trigger_type,
            schedule_type=payload.schedule_type,
        )
        logger.info(
            "Generate schedule completed channel_service_id=%s run_id=%s entry_count=%s",
            result.channel_service_id,
            result.run_id,
            result.entry_count,
        )
        return GenerateScheduleResponse(
            channel_service_id=result.channel_service_id,
            run_id=result.run_id,
            entry_count=result.entry_count,
        )
    except Exception as exc:
        logger.exception("Generate schedule failed channel_service_id=%s error=%s", channel_service_id, exc)
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/channels/{channel_service_id}/schedule/active/download")
def download_active_schedule_route(channel_service_id: str) -> JSONResponse:
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        raise HTTPException(status_code=500, detail="DATABASE_URL is not set")
    payload = get_active_schedule_json(db_url, channel_service_id)
    if payload is None:
        raise HTTPException(status_code=404, detail="Active schedule JSON not found")
    headers = {
        "Content-Disposition": f'attachment; filename="{channel_service_id}_active_schedule.json"'
    }
    return JSONResponse(content=payload, headers=headers)


@app.get("/channels/{channel_service_id}/runs/{run_id}/schedule/download")
def download_run_schedule_route(channel_service_id: str, run_id: str) -> JSONResponse:
    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        raise HTTPException(status_code=500, detail="DATABASE_URL is not set")
    payload = get_run_schedule_json(db_url, channel_service_id, run_id)
    if payload is None:
        raise HTTPException(status_code=404, detail="Run schedule JSON not found")
    headers = {
        "Content-Disposition": f'attachment; filename="{channel_service_id}_{run_id}_schedule.json"'
    }
    return JSONResponse(content=payload, headers=headers)


def run() -> None:
    logger.info("Starting API server")
    uvicorn.run(
        "src.api.main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", "8000")),
        reload=False,
    )


if __name__ == "__main__":
    run()

