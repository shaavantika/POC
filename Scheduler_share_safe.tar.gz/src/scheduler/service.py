from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from psycopg import connect

from src.scheduler.repository import (
    create_run,
    get_feed_id_for_channel,
    get_valid_assets,
    mark_run_failed,
    persist_entries_and_activate,
)
from src.scheduler.strategies import get_strategy
from src.scheduler.validation import validate_entries
from src.common.logging_config import get_logger

logger = get_logger("scheduler.service")


@dataclass(slots=True)
class ScheduleResult:
    run_id: str
    entry_count: int
    channel_service_id: str


def _build_schedule_json(
    channel_service_id: str,
    run_id: str,
    window_start: datetime,
    window_end: datetime,
    entries,
) -> dict:
    return {
        "channel_service_id": channel_service_id,
        "run_id": run_id,
        "window_start": window_start.isoformat(),
        "window_end": window_end.isoformat(),
        "entry_count": len(entries),
        "entries": [
            {
                "sequence_no": e.sequence_no,
                "starts_at": e.starts_at.isoformat(),
                "ends_at": e.ends_at.isoformat(),
                "asset_id": e.asset_id,
                "asset_type": e.asset_type,
                "title": e.title,
                "season_number": e.season_number,
                "episode_number": e.episode_number,
                "duration_ms": e.duration_ms,
            }
            for e in entries
        ],
    }


def generate_schedule(
    db_url: str,
    channel_service_id: str,
    window_hours: int = 24,
    trigger_type: str = "manual",
    schedule_type: str = "binge",
) -> ScheduleResult:
    logger.info(
        "Schedule generation started channel_service_id=%s window_hours=%s trigger_type=%s schedule_type=%s",
        channel_service_id,
        window_hours,
        trigger_type,
        schedule_type,
    )
    window_start = datetime.now(timezone.utc)
    window_end = window_start + timedelta(hours=window_hours)

    with connect(db_url) as conn:
        feed_id = get_feed_id_for_channel(conn, channel_service_id)
        if not feed_id:
            logger.error("Channel mapping missing channel_service_id=%s", channel_service_id)
            raise ValueError(f"Channel mapping not found for {channel_service_id}")

        run_id = create_run(
            conn=conn,
            channel_service_id=channel_service_id,
            window_start=window_start,
            window_end=window_end,
            trigger_type=trigger_type,
            source_feed_id=feed_id,
        )

        try:
            episodes, slates = get_valid_assets(conn, feed_id, window_start)
            strategy = get_strategy(schedule_type)
            entries = strategy.build_entries(
                episode_assets=episodes,
                fallback_slates=slates,
                window_start=window_start,
                window_end=window_end,
            )
            if not entries:
                raise ValueError("No valid assets found to build schedule")
            validation = validate_entries(
                entries=entries,
                window_start=window_start,
                window_end=window_end,
                minimum_coverage_ratio=0.95,
            )
            if not validation.ok:
                raise ValueError(validation.message or "Schedule validation failed")

            persist_entries_and_activate(
                conn=conn,
                run_id=run_id,
                channel_service_id=channel_service_id,
                entries=entries,
                schedule_json=_build_schedule_json(
                    channel_service_id=channel_service_id,
                    run_id=str(run_id),
                    window_start=window_start,
                    window_end=window_end,
                    entries=entries,
                ),
            )
            conn.commit()
            logger.info(
                "Schedule generation succeeded channel_service_id=%s run_id=%s entries=%s",
                channel_service_id,
                run_id,
                len(entries),
            )
        except Exception as exc:
            logger.exception(
                "Schedule generation failed channel_service_id=%s run_id=%s error=%s",
                channel_service_id,
                run_id,
                exc,
            )
            mark_run_failed(conn, run_id, str(exc))
            conn.commit()
            raise

    return ScheduleResult(
        run_id=str(run_id),
        entry_count=len(entries),
        channel_service_id=channel_service_id,
    )

