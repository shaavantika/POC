# UI Reference Dashboard (Standalone)

This is a separate frontend-only reference UI to visualize backend status.

## Purpose
- Show what the scheduler backend is doing (feeds, channels, runs, entries).
- Help operators/debugging during development.
- Stay decoupled from backend implementation.

## Run

From project root:

```bash
python3 -m http.server 8080 -d ui-reference
```

Open:
- [http://localhost:8080](http://localhost:8080)

## Data Sources

The UI uses real backend APIs only. Set `API_BASE_URL` in `app.js` if backend is not on `http://localhost:8000`.

Expected endpoints:
- `POST /channels/register`
- `GET /feeds`
- `GET /channels`
- `GET /channels/{channelId}/runs`
- `GET /channels/{channelId}/schedule/active`

## Notes
- This dashboard is reference UI only; channel registration is supported, but no ingest/schedule trigger buttons are included yet.
- All code is isolated under `ui-reference/`.

