const API_BASE_URL = "http://localhost:8007";

const modeBadge = document.getElementById("modeBadge");
const refreshBtn = document.getElementById("refreshBtn");
const registerForm = document.getElementById("registerForm");
const registerMessage = document.getElementById("registerMessage");
const feedsCount = document.getElementById("feedsCount");
const channelsCount = document.getElementById("channelsCount");
const activeRunsCount = document.getElementById("activeRunsCount");
const failedRunsCount = document.getElementById("failedRunsCount");
const feedsTableBody = document.getElementById("feedsTableBody");
const channelSelect = document.getElementById("channelSelect");
const generateScheduleBtn = document.getElementById("generateScheduleBtn");
const downloadScheduleBtn = document.getElementById("downloadScheduleBtn");
const generateMessage = document.getElementById("generateMessage");
const channelInfo = document.getElementById("channelInfo");
const runsTableBody = document.getElementById("runsTableBody");
const entriesTableBody = document.getElementById("entriesTableBody");
const assetsTableBody = document.getElementById("assetsTableBody");
modeBadge.textContent = "API";

async function getJson(path) {
  const res = await fetch(`${API_BASE_URL}${path}`);
  if (!res.ok) {
    throw new Error(`Request failed: ${res.status} ${path}`);
  }
  return res.json();
}

function formatTime(iso) {
  if (!iso) return "-";
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

function clearEl(el) {
  while (el.firstChild) el.removeChild(el.firstChild);
}

function row(cells) {
  const tr = document.createElement("tr");
  cells.forEach((content) => {
    const td = document.createElement("td");
    if (content instanceof Node) td.appendChild(content);
    else td.textContent = content ?? "-";
    tr.appendChild(td);
  });
  return tr;
}

function statusNode(status) {
  const span = document.createElement("span");
  span.textContent = status;
  span.className = `status ${String(status).toLowerCase()}`;
  return span;
}

async function loadData() {
  const [feeds, channels] = await Promise.all([getJson("/feeds"), getJson("/channels")]);

  feedsCount.textContent = String(feeds.length);
  channelsCount.textContent = String(channels.length);

  clearEl(feedsTableBody);
  feeds.forEach((f) => {
    feedsTableBody.appendChild(
      row([
        f.url,
        String(f.enabled),
        formatTime(f.last_fetch_at),
        String(f.last_http_status ?? "-"),
        f.last_error ?? "-",
      ])
    );
  });

  clearEl(channelSelect);
  channels.forEach((c) => {
    const opt = document.createElement("option");
    opt.value = c.channel_service_id;
    opt.textContent = c.channel_service_id;
    channelSelect.appendChild(opt);
  });

  if (channels.length > 0) {
    await loadChannel(channels[0].channel_service_id);
  } else {
    channelInfo.textContent = "No channels configured.";
    clearEl(runsTableBody);
    clearEl(entriesTableBody);
  }
}

async function loadChannel(channelId) {
  const [runs, entries, assets] = await Promise.all([
    getJson(`/channels/${encodeURIComponent(channelId)}/runs`),
    getJson(`/channels/${encodeURIComponent(channelId)}/schedule/active`),
    getJson(`/channels/${encodeURIComponent(channelId)}/assets`),
  ]);

  channelInfo.textContent = `Channel: ${channelId} | Runs: ${runs.length}`;
  activeRunsCount.textContent = String(runs.filter((r) => r.is_active).length);
  failedRunsCount.textContent = String(
    runs.filter((r) => String(r.status).toLowerCase() === "failed").length
  );

  clearEl(runsTableBody);
  runs.forEach((r) => {
    runsTableBody.appendChild(
      row([
        r.id,
        statusNode(r.status),
        String(!!r.is_active),
        String(r.generated_entry_count ?? 0),
        formatTime(r.created_at),
        r.error_message ?? "-",
      ])
    );
  });

  clearEl(entriesTableBody);
  entries.forEach((e) => {
    entriesTableBody.appendChild(
      row([
        String(e.sequence_no),
        formatTime(e.starts_at),
        formatTime(e.ends_at),
        e.asset_id,
        e.asset_type,
        e.title ?? "-",
      ])
    );
  });

  clearEl(assetsTableBody);
  assets.forEach((a) => {
    assetsTableBody.appendChild(
      row([
        a.asset_id,
        a.asset_type,
        a.season_number ?? "-",
        a.episode_number ?? "-",
        String(a.duration_ms ?? "-"),
        formatTime(a.valid_from),
        formatTime(a.valid_to),
        a.title ?? "-",
      ])
    );
  });
}

refreshBtn.addEventListener("click", async () => {
  refreshBtn.disabled = true;
  try {
    await loadData();
  } catch (err) {
    console.error(err);
    alert(`Failed to refresh dashboard: ${err.message}`);
  } finally {
    refreshBtn.disabled = false;
  }
});

channelSelect.addEventListener("change", async () => {
  try {
    await loadChannel(channelSelect.value);
  } catch (err) {
    console.error(err);
    alert(`Failed to load channel details: ${err.message}`);
  }
});

registerForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  registerMessage.textContent = "";
  const payload = {
    channel_service_id: document.getElementById("channelServiceId").value.trim(),
    mrss_url: document.getElementById("mrssUrl").value.trim(),
    fetch_interval_seconds: Number(document.getElementById("fetchInterval").value),
    enabled: document.getElementById("enabled").value === "true",
  };
  try {
    const res = await fetch(`${API_BASE_URL}/channels/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.detail || `Request failed: ${res.status}`);
    }
    const data = await res.json();
    registerMessage.textContent = `Registered ${data.channel_service_id} -> ${data.mrss_url}`;
    await loadData();
  } catch (err) {
    console.error(err);
    registerMessage.textContent = `Registration failed: ${err.message}`;
  }
});

generateScheduleBtn.addEventListener("click", async () => {
  const channelId = channelSelect.value;
  if (!channelId) {
    generateMessage.textContent = "Select a channel first.";
    return;
  }
  generateScheduleBtn.disabled = true;
  generateMessage.textContent = "";
  try {
    const res = await fetch(
      `${API_BASE_URL}/channels/${encodeURIComponent(channelId)}/schedule/generate`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          window_hours: 24,
          trigger_type: "manual",
          schedule_type: "binge",
        }),
      }
    );
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.detail || `Request failed: ${res.status}`);
    }
    const data = await res.json();
    generateMessage.textContent = `Generated run ${data.run_id} with ${data.entry_count} entries`;
    await loadChannel(channelId);
  } catch (err) {
    console.error(err);
    generateMessage.textContent = `Generate failed: ${err.message}`;
  } finally {
    generateScheduleBtn.disabled = false;
  }
});

downloadScheduleBtn.addEventListener("click", async () => {
  const channelId = channelSelect.value;
  if (!channelId) {
    generateMessage.textContent = "Select a channel first.";
    return;
  }
  try {
    const res = await fetch(
      `${API_BASE_URL}/channels/${encodeURIComponent(channelId)}/schedule/active/download`
    );
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.detail || `Request failed: ${res.status}`);
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${channelId}_active_schedule.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    generateMessage.textContent = "Active schedule JSON downloaded.";
  } catch (err) {
    console.error(err);
    generateMessage.textContent = `Download failed: ${err.message}`;
  }
});

loadData().catch((err) => {
  console.error(err);
  alert(`Initial load failed: ${err.message}`);
});

